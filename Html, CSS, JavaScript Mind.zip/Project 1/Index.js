document.getElementById("submitButton").onclick = function(){
    var inputText = document.getElementById("textInput").value;
    var inputPassword = document.getElementById("passwordInput").value;
    alert("Your Name: " + inputText + " | Your Password: " + inputPassword)
}
const checkboxInput = document.getElementById("checkboxInput");
const submitButton = document.getElementById("submitButton");
const SubResult = document.getElementById("SubResult");

checkboxInput.onclick = function() {
    if(checkboxInput.checked){
    SubResult.textContent = `Thanks To Remember Me`;
    }
    else{
    SubResult.textContent = ``;
    }
}